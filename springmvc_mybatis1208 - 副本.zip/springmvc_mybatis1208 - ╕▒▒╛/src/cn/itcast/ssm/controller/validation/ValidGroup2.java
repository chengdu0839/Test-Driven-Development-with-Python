package cn.itcast.ssm.controller.validation;

/**
 * 
 * <p>Title: ValidGroup1</p>
 * <p>Description:校验分组 </p>
 * <p>Company: www.itcast.com</p> 
 * @author	传智.燕青
 * @date	2015-4-14上午11:27:30
 * @version 1.0
 */
public interface ValidGroup2 {
	//接口中不需要定义任何方法，仅是对不同的校验规则进行分组

}
